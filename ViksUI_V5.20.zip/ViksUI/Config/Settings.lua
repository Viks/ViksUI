﻿local T, Viks, L, _ = unpack(ViksUI)
if Viks.Filger.filger and Viks.unitframes.enable ~= true then return end

Viks["filger_settings"] = {
	config_mode = false,
	max_test_icon = 5,
	show_tooltip = true,
}